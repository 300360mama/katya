<?php $__env->startSection("content"); ?>
   <article>
      

       <?php if($article_number === 1): ?>
     
        <?php echo $__env->make('blocks.article1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent("article1"); ?>

       <?php elseif($article_number === 2): ?>
    
        <?php echo $__env->make('blocks.article2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('article2'); ?>

       <?php elseif($article_number === 3): ?>
    
        <?php echo $__env->make('blocks.article3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('article3'); ?>

       <?php elseif($article_number === 4): ?>
    
        <?php echo $__env->make('blocks.article4', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('article4'); ?>

       <?php elseif($article_number === 5): ?>
    
        <?php echo $__env->make('blocks.article5', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('article5'); ?>
       <?php else: ?>
    
       article not found
       <?php endif; ?>
     

      

    
   </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('blocks.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>